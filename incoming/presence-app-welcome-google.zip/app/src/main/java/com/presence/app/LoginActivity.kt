package com.presence.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.presence.app.Ui.addTo

/** Login and sign up on one screen, like the website. */
class LoginActivity : BaseActivity() {
    companion object {
        // Set this to your live privacy policy page before release.
        const val PRIVACY_URL = "https://example.com/presence-privacy"
    }

    override val needsLogin: Boolean get() = false

    private var signUp = false
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var heading: TextView
    private lateinit var tagline: TextView
    private lateinit var msg: TextView
    private lateinit var submit: Button
    private lateinit var spin: SpinnerRingView
    private lateinit var busyPill: FrameLayout
    private lateinit var forgotRow: LinearLayout
    private lateinit var tabLogin: TextView
    private lateinit var tabSignUp: TextView
    private lateinit var welcomeView: LinearLayout
    private lateinit var formView: FrameLayout
    private lateinit var wMsg: TextView
    private var googleBusy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = this

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        // Blue hero, running up behind the status bar
        val hero = AuthUi.HeroLayout(c)
        hero.orientation = LinearLayout.VERTICAL
        hero.gravity = Gravity.CENTER
        hero.setPadding(Ui.dp(c, 24), Ui.dp(c, 28), Ui.dp(c, 24), Ui.dp(c, 52))
        Ui.padInsets(hero, top = true)
        val ls = Ui.dp(c, 60)
        hero.addView(AuthUi.logo(c, 60), LinearLayout.LayoutParams(ls, ls))
        val name = Ui.text(c, "PRESENCE", 22f, Ui.WHITE, Ui.BOLD)
        name.letterSpacing = 0.1f
        name.gravity = Gravity.CENTER
        hero.addTo(name, 18)
        val tag = Ui.text(c, "Train your presence, one drill at a time.", 12f, Color.parseColor("#CCE4FF"), Ui.REG)
        tag.gravity = Gravity.CENTER
        hero.addTo(tag, 6)
        root.addView(hero, LinearLayout.LayoutParams(-1, -2))

        // Form card, overlapping the hero
        val card = Ui.card(c)
        card.background = Ui.rounded(c, Ui.SURFACE, 28)
        card.elevation = Ui.dp(c, 6).toFloat()
        card.setPadding(Ui.dp(c, 22), Ui.dp(c, 24), Ui.dp(c, 22), Ui.dp(c, 20))

        // Login | Sign up switch
        val tabs = LinearLayout(c)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.background = Ui.rounded(c, Ui.FIELD, 22, Ui.LINE, 1)
        tabs.setPadding(Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4))
        tabLogin = Ui.text(c, "Login", 15f, Ui.WHITE, Ui.BOLD)
        tabSignUp = Ui.text(c, "Sign up", 15f, Ui.MUTED, Ui.BOLD)
        for (t in listOf(tabLogin, tabSignUp)) {
            t.gravity = Gravity.CENTER
            t.setPadding(0, Ui.dp(c, 11), 0, Ui.dp(c, 11))
            tabs.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        tabLogin.setOnClickListener { setMode(false) }
        tabSignUp.setOnClickListener { setMode(true) }
        card.addTo(tabs)

        heading = Ui.text(c, "Welcome Back", 24f, Ui.TEXT, Ui.BOLD)
        heading.gravity = Gravity.CENTER
        card.addTo(heading, 20)
        tagline = Ui.text(c, "Login to get access to training", 14f, Ui.MUTED, Ui.REG)
        tagline.gravity = Gravity.CENTER
        card.addTo(tagline, 4)

        val emailRow = AuthUi.inputRow(c, AuthUi.MAIL, "Email address", false)
        email = emailRow.second
        card.addTo(emailRow.first, 22)
        val passRow = AuthUi.inputRow(c, AuthUi.LOCK, "Password", true)
        password = passRow.second
        password.imeOptions = EditorInfo.IME_ACTION_DONE
        card.addTo(passRow.first, 12)

        submit = Ui.pill(c, "Login")
        submit.textSize = 17f
        submit.elevation = Ui.dp(c, 3).toFloat()
        // while signing in the button is swapped for this blue pill with a spinner
        spin = SpinnerRingView(c, Ui.WHITE, Color.parseColor("#55FFFFFF"), 3)
        busyPill = FrameLayout(c)
        busyPill.background = Ui.rounded(c, Ui.BLUE, 28)
        busyPill.visibility = View.GONE
        busyPill.addView(spin, FrameLayout.LayoutParams(Ui.dp(c, 28), Ui.dp(c, 28), Gravity.CENTER))
        val submitWrap = FrameLayout(c)
        submitWrap.addView(submit, FrameLayout.LayoutParams(-1, -2))
        submitWrap.addView(busyPill, FrameLayout.LayoutParams(-1, Ui.dp(c, 56)))
        card.addTo(submitWrap, 22)

        msg = Ui.text(c, "", 12f, Ui.RED, Ui.MED)
        msg.gravity = Gravity.CENTER
        card.addTo(msg, 12)

        forgotRow = LinearLayout(c)
        forgotRow.orientation = LinearLayout.HORIZONTAL
        forgotRow.gravity = Gravity.CENTER
        val forgotMuted = Ui.text(c, "Forgot your password? ", 14f, Ui.MUTED, Ui.REG)
        val forgotLink = Ui.text(c, "Reset it", 14f, Ui.BLUE, Ui.BOLD)
        forgotRow.addView(forgotMuted)
        forgotRow.addView(forgotLink)
        card.addTo(forgotRow, 14)


        val privacy = Ui.text(c, "Privacy policy", 12f, Ui.MUTED, Ui.REG)
        privacy.gravity = Gravity.CENTER
        privacy.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY_URL))) }
        card.addTo(privacy, 14)
        val back = Ui.text(c, "Back", 14f, Ui.MUTED, Ui.MED)
        back.gravity = Gravity.CENTER
        back.setPadding(Ui.dp(c, 24), Ui.dp(c, 8), Ui.dp(c, 24), Ui.dp(c, 4))
        back.setOnClickListener { showWelcome() }
        card.addTo(back, 6)

        val cardLp = LinearLayout.LayoutParams(-1, -2)
        cardLp.setMargins(Ui.dp(c, 20), -Ui.dp(c, 30), Ui.dp(c, 20), Ui.dp(c, 24))
        root.addView(card, cardLp)

        Ui.padInsets(root, bottom = true, ime = true)

        val scroll = ScrollView(c)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(Ui.BG)
        scroll.addView(root)
        val scrim = Ui.statusScrim(c)
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            scrim.alpha = Math.min(1f, y / Ui.dp(c, 60).toFloat())
        }
        formView = FrameLayout(c)
        formView.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        formView.addView(scrim)
        formView.visibility = View.GONE

        welcomeView = buildWelcome()
        val frame = FrameLayout(c)
        frame.setBackgroundColor(Ui.BG)
        frame.addView(formView, FrameLayout.LayoutParams(-1, -1))
        frame.addView(welcomeView, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (formView.visibility == View.VISIBLE) showWelcome() else finish()
            }
        })

        submit.setOnClickListener { doSubmit() }
        password.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                doSubmit()
                true
            } else {
                false
            }
        }
        forgotLink.setOnClickListener {
            val i = Intent(this, ForgotPasswordActivity::class.java)
            i.putExtra("email", email.text.toString().trim())
            startActivity(i)
        }

        setMode(false)
    }

    private fun setMode(up: Boolean) {
        signUp = up
        msg.text = ""
        heading.text = if (up) "Create Account" else "Welcome Back"
        tagline.text = if (up) "Start your presence training journey" else "Login to get access to training"
        submit.text = if (up) "Sign Up" else "Login"
        tabLogin.background = if (!up) Ui.rounded(this, Ui.BLUE, 18) else null
        tabLogin.setTextColor(if (!up) Ui.WHITE else Ui.MUTED)
        tabSignUp.background = if (up) Ui.rounded(this, Ui.BLUE, 18) else null
        tabSignUp.setTextColor(if (up) Ui.WHITE else Ui.MUTED)
        forgotRow.visibility = if (up) View.GONE else View.VISIBLE
    }

    private fun showForm(up: Boolean) {
        setMode(up)
        welcomeView.visibility = View.GONE
        formView.visibility = View.VISIBLE
    }

    private fun showWelcome() {
        currentFocus?.let {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(it.windowToken, 0)
        }
        formView.visibility = View.GONE
        welcomeView.visibility = View.VISIBLE
    }

    /** First screen: big logo, then Login / Create account / Continue with Google. */
    private fun buildWelcome(): LinearLayout {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(Ui.BG)

        val hero = AuthUi.HeroLayout(c)
        hero.orientation = LinearLayout.VERTICAL
        hero.gravity = Gravity.CENTER
        hero.setPadding(Ui.dp(c, 24), Ui.dp(c, 28), Ui.dp(c, 24), Ui.dp(c, 28))
        Ui.padInsets(hero, top = true)
        val ls = Ui.dp(c, 112)
        hero.addView(AuthUi.logo(c, 112), LinearLayout.LayoutParams(ls, ls))
        val name = Ui.text(c, "PRESENCE", 32f, Ui.WHITE, Ui.BOLD)
        name.letterSpacing = 0.12f
        name.gravity = Gravity.CENTER
        hero.addTo(name, 28)
        val tag = Ui.text(c, "Train your presence, one drill at a time.", 15f, Color.parseColor("#CCE4FF"), Ui.REG)
        tag.gravity = Gravity.CENTER
        hero.addTo(tag, 10)
        col.addView(hero, LinearLayout.LayoutParams(-1, 0, 1f))

        val btns = LinearLayout(c)
        btns.orientation = LinearLayout.VERTICAL
        btns.setPadding(Ui.dp(c, 24), Ui.dp(c, 28), Ui.dp(c, 24), Ui.dp(c, 20))

        val login = Ui.pill(c, "Login")
        login.textSize = 17f
        login.elevation = Ui.dp(c, 3).toFloat()
        login.setOnClickListener { showForm(false) }
        btns.addView(login, LinearLayout.LayoutParams(-1, -2))

        val create = Ui.pill(c, "Create account", Ui.BG, Ui.BLUE)
        create.textSize = 17f
        create.background = Ui.rounded(c, Ui.BG, 28, Ui.BLUE, 2)
        create.setOnClickListener { showForm(true) }
        val cLp = LinearLayout.LayoutParams(-1, -2)
        cLp.topMargin = Ui.dp(c, 14)
        btns.addView(create, cLp)

        val fast = Ui.text(c, "Login or sign up faster with", 13f, Ui.MUTED, Ui.REG)
        fast.gravity = Gravity.CENTER
        btns.addTo(fast, 18)

        val g = LinearLayout(c)
        g.orientation = LinearLayout.HORIZONTAL
        g.gravity = Gravity.CENTER
        g.background = Ui.rounded(c, Ui.SURFACE, 28, Ui.LINE, 1)
        g.minimumHeight = Ui.dp(c, 56)
        g.setPadding(Ui.dp(c, 20), 0, Ui.dp(c, 20), 0)
        g.isClickable = true
        g.setOnClickListener { doGoogle() }
        val gLp = LinearLayout.LayoutParams(Ui.dp(c, 22), Ui.dp(c, 22))
        gLp.rightMargin = Ui.dp(c, 12)
        g.addView(GoogleGView(c), gLp)
        g.addView(Ui.text(c, "Continue with Google", 16f, Ui.TEXT, Ui.BOLD))
        btns.addTo(g, 12)

        wMsg = Ui.text(c, "", 12f, Ui.RED, Ui.MED)
        wMsg.gravity = Gravity.CENTER
        btns.addTo(wMsg, 10)

        col.addView(btns, LinearLayout.LayoutParams(-1, -2))
        Ui.padInsets(btns, bottom = true)
        return col
    }

    /** Shows Google's account picker on top of the app (no browser). Falls back to the browser only if the app isn't set up for it. */
    private fun doGoogle() {
        if (googleBusy) return
        if (Api.GOOGLE_WEB_CLIENT_ID.isEmpty()) { showSetupHelp("The Google Web Client ID is not set in the app yet."); return }
        googleBusy = true
        wMsg.text = ""
        val option = com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
            .Builder(Api.GOOGLE_WEB_CLIENT_ID).build()
        val request = androidx.credentials.GetCredentialRequest.Builder().addCredentialOption(option).build()
        androidx.credentials.CredentialManager.create(this).getCredentialAsync(
            this, request, null, androidx.core.content.ContextCompat.getMainExecutor(this),
            object : androidx.credentials.CredentialManagerCallback<androidx.credentials.GetCredentialResponse, androidx.credentials.exceptions.GetCredentialException> {
                override fun onResult(result: androidx.credentials.GetCredentialResponse) {
                    val cred = result.credential
                    if (cred is androidx.credentials.CustomCredential &&
                        cred.type == com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        val idToken = com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
                            .createFrom(cred.data).idToken
                        Thread {
                            val r = Api.signInWithGoogleIdToken(idToken)
                            runOnUiThread {
                                if (isFinishing) return@runOnUiThread
                                if (r.ok && Session.loggedIn()) {
                                    Sync.refresh {
                                        googleBusy = false
                                        if (!isFinishing) goHome()
                                    }
                                } else {
                                    googleBusy = false
                                    wMsg.text = "Could not finish Google sign-in. Please try again."
                                }
                            }
                        }.start()
                    } else {
                        googleBusy = false
                        wMsg.text = "Google sign-in did not work. Please try again."
                    }
                }
                override fun onError(e: androidx.credentials.exceptions.GetCredentialException) {
                    googleBusy = false
                    if (e is androidx.credentials.exceptions.GetCredentialCancellationException) return
                    showSetupHelp("Google popup could not open (" + e.javaClass.simpleName + "). Add this app in Google Cloud as an Android client with the values below.")
                }
            })
    }

    /** The signing fingerprint of this installed app. Google needs it once to allow the in-app account popup. */
    private fun signingSha1(): String = try {
        val pm = packageManager
        val sigs = if (android.os.Build.VERSION.SDK_INT >= 28)
            pm.getPackageInfo(packageName, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
        else @Suppress("DEPRECATION") pm.getPackageInfo(packageName, android.content.pm.PackageManager.GET_SIGNATURES).signatures
        java.security.MessageDigest.getInstance("SHA-1").digest(sigs!![0].toByteArray())
            .joinToString(":") { "%02X".format(it) }
    } catch (e: Exception) { "unknown" }

    /** Shows what is missing, with the fingerprint. Tapping the text copies the fingerprint. */
    private fun showSetupHelp(reason: String) {
        val sha = signingSha1()
        wMsg.setTextColor(Ui.RED)
        wMsg.text = reason + "\n\nPackage: " + packageName + "\nSHA-1: " + sha + "\n\nTap here to copy the SHA-1"
        wMsg.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("SHA-1", sha))
            android.widget.Toast.makeText(this, "SHA-1 copied", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMsg(text: String, ok: Boolean) {
        msg.setTextColor(if (ok) Ui.GREEN else Ui.RED)
        msg.text = text
    }

    private fun busy(on: Boolean) {
        submit.isEnabled = !on
        submit.visibility = if (on) View.INVISIBLE else View.VISIBLE
        busyPill.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun doSubmit() {
        val e = email.text.toString().trim()
        val p = password.text.toString()
        if (!submit.isEnabled) return   // already working (keyboard Done pressed twice)
        if (e.isEmpty() || p.isEmpty()) {
            showMsg("Please fill in all fields.", false)
            return
        }
        showMsg("", true)
        busy(true)
        val up = signUp
        Thread {
            val r = if (up) Api.signUp(e, p) else Api.signIn(e, p)
            val loggedIn = r.ok && Session.loggedIn()
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (loggedIn) {
                    // keep the spinner going inside the button until the user's data is loaded,
                    // and only then open the app
                    Sync.refresh {
                        if (!isFinishing) {
                            busy(false)
                            goHome()
                        }
                    }
                } else if (r.ok) {
                    busy(false)
                    showMsg("Check your email to confirm your account.", true)
                } else {
                    busy(false)
                    showMsg(r.message(), false)
                }
            }
        }.start()
    }

    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
