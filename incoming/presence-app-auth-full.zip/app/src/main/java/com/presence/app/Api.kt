package com.presence.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Talks to the same Supabase project as the Presence website. The anon key is public by design. */
object Api {
    private const val URL = "https://chdnbthhmqituvrelrjg.supabase.co"
    /** Where invite and reset links send the person back to the app. */
    const val APP_LINK = "presence://auth-callback"
    private const val KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNoZG5idGhobXFpdHV2cmVscmpnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5MDc1MDUsImV4cCI6MjA4ODQ4MzUwNX0.tKp1_FbquRNiilyjajlGnUGhK8dnpZff9EsBTYS1c6o"

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
    private val JSON_TYPE = "application/json".toMediaType()

    class Result(val ok: Boolean, val code: Int, val body: String) {
        /** A sentence the user can read when a request failed. */
        fun message(): String {
            if (code == 0) return "No internet connection. Please try again."
            if (code == 429) return "Too many attempts. Please wait a few minutes and try again."
            try {
                val o = JSONObject(body)
                for (k in listOf("msg", "error_description", "message", "error")) {
                    val t = o.optString(k, "")
                    if (t.isNotBlank()) return t
                }
            } catch (e: Exception) {
            }
            if (code >= 500) return "The server had a problem. Please try again in a moment."
            return "Something went wrong (error $code). Please try again."
        }
    }

    private fun call(req: Request): Result {
        return try {
            http.newCall(req).execute().use { resp ->
                Result(resp.isSuccessful, resp.code, resp.body?.string() ?: "")
            }
        } catch (e: Exception) {
            Result(false, 0, "")
        }
    }

    private fun builder(path: String, token: String): Request.Builder {
        return Request.Builder()
            .url(URL + path)
            .header("apikey", KEY)
            .header("Authorization", "Bearer $token")
    }

    // ---------- auth ----------

    /** Stores the login from a Supabase auth response. False if the response has no session in it. */
    private fun saveSession(json: String): Boolean {
        try {
            val o = JSONObject(json)
            val uid = o.optJSONObject("user")?.optString("id", "") ?: ""
            if (uid.isEmpty()) return false
            Session.save(
                o.getString("access_token"),
                o.getString("refresh_token"),
                uid,
                System.currentTimeMillis() + o.optLong("expires_in", 3600L) * 1000L
            )
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun signIn(email: String, password: String): Result {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val r = call(builder("/auth/v1/token?grant_type=password", KEY).post(body.toRequestBody(JSON_TYPE)).build())
        if (r.ok && !saveSession(r.body)) return Result(false, 500, "")
        return r
    }

    /**
     * Creates the account. The confirmation email's link returns into the app (APP_LINK, must be on Supabase's
     * Redirect URLs allowlist). The caller checks Session.loggedIn(): with email confirmation on, there is no session yet.
     */
    fun signUp(email: String, password: String, name: String): Result {
        val body = JSONObject().put("email", email).put("password", password)
            .put("data", JSONObject().put("full_name", name)).toString()
        val redirect = URLEncoder.encode(APP_LINK, "UTF-8")
        val r = call(builder("/auth/v1/signup?redirect_to=$redirect", KEY).post(body.toRequestBody(JSON_TYPE)).build())
        if (r.ok && saveSession(r.body)) return r
        if (r.ok) {
            // For an email that already has an account Supabase answers "ok" with no identities and sends nothing.
            val exists = try {
                val o = JSONObject(r.body)
                val u = o.optJSONObject("user") ?: o
                u.optJSONArray("identities")?.length() == 0
            } catch (e: Exception) { false }
            if (exists) return Result(false, 400, JSONObject().put("msg", "This email already has an account. Please log in.").toString())
        }
        return r
    }

    /** The signed-in user's account (email, user_metadata with name and Google photo), or null. */
    fun fetchUser(): JSONObject? {
        val r = authed("GET", "/auth/v1/user", null, null)
        if (!r.ok) return null
        return try { JSONObject(r.body) } catch (e: Exception) { null }
    }


    /**
     * Web application OAuth client ID from Google Cloud Console (the one entered in Supabase > Auth > Google).
     * While this is empty the app falls back to the browser sign-in.
     */
    const val GOOGLE_WEB_CLIENT_ID = "233197518398-5v753c5p5euhm9ndmqktqq1iaalpvu6n.apps.googleusercontent.com"

    /** Signs in with the Google ID token from the in-app account picker. */
    fun signInWithGoogleIdToken(idToken: String): Result {
        val body = JSONObject().put("provider", "google").put("id_token", idToken).toString()
        val r = call(builder("/auth/v1/token?grant_type=id_token", KEY).post(body.toRequestBody(JSON_TYPE)).build())
        if (r.ok && !saveSession(r.body)) return Result(false, 500, "")
        return r
    }

    /** Address that opens Google sign-in in the phone's browser. Supabase sends the user back to presence://auth-callback. */
    fun googleSignInUrl(): String =
        URL + "/auth/v1/authorize?provider=google&redirect_to=" + URLEncoder.encode(APP_LINK, "UTF-8")

    /** The reset email's link comes back into the app (presence://auth-callback). Must be on Supabase's allowlist. */
    fun sendReset(email: String): Result {
        val body = JSONObject().put("email", email).toString()
        val redirect = URLEncoder.encode(APP_LINK, "UTF-8")
        return call(builder("/auth/v1/recover?redirect_to=$redirect", KEY).post(body.toRequestBody(JSON_TYPE)).build())
    }

    /** Signs in with the tokens from an invite or reset link. False if the login is not valid. */
    fun sessionFromLink(access: String, refresh: String, expiresIn: Long): Boolean {
        val r = call(builder("/auth/v1/user", access).get().build())
        if (!r.ok) return false
        val uid = try { JSONObject(r.body).optString("id", "") } catch (e: Exception) { "" }
        if (uid.isEmpty()) return false
        Session.save(access, refresh, uid, System.currentTimeMillis() + expiresIn * 1000L)
        return true
    }

    /** Sets the password of the signed-in user (an invited user has none yet). */
    fun setPassword(password: String): Result {
        val body = JSONObject().put("password", password).toString()
        return call(builder("/auth/v1/user", Session.access).put(body.toRequestBody(JSON_TYPE)).build())
    }

    /** Deletes the signed-in account and its data (see supabase/migrations/003_delete_account.sql). */
    fun deleteAccount(): Result = authed("POST", "/rest/v1/rpc/delete_my_account", "{}", null)

    @Synchronized
    private fun refreshToken(): Boolean {
        val refresh = Session.refresh
        if (refresh.isEmpty()) return false
        val body = JSONObject().put("refresh_token", refresh).toString()
        val r = call(builder("/auth/v1/token?grant_type=refresh_token", KEY).post(body.toRequestBody(JSON_TYPE)).build())
        if (r.ok) return saveSession(r.body)
        // The login itself was rejected: it is no longer valid. A network error keeps the login.
        if (r.code == 400 || r.code == 401) Session.clear()
        return false
    }

    private fun doAuthed(method: String, path: String, body: String?, prefer: String?): Result {
        val b = builder(path, Session.access)
        if (prefer != null) b.header("Prefer", prefer)
        val payload = (body ?: "{}").toRequestBody(JSON_TYPE)
        when (method) {
            "POST" -> b.post(payload)
            "PATCH" -> b.patch(payload)
            else -> b.get()
        }
        return call(b.build())
    }

    private fun authed(method: String, path: String, body: String?, prefer: String?): Result {
        if (Session.access.isEmpty() || System.currentTimeMillis() > Session.expiresAt - 60_000L) refreshToken()
        var r = doAuthed(method, path, body, prefer)
        if (r.code == 401 && refreshToken()) r = doAuthed(method, path, body, prefer)
        return r
    }

    // ---------- data (same tables and columns as the website) ----------

    /** The user's profile row, an empty object if they have none yet, or null if the request failed. */
    fun fetchProfile(uid: String): JSONObject? {
        val r = authed("GET", "/rest/v1/profiles?select=*&id=eq.$uid", null, null)
        if (!r.ok) return null
        return try {
            val arr = JSONArray(r.body)
            if (arr.length() == 0) JSONObject() else arr.getJSONObject(0)
        } catch (e: Exception) {
            null
        }
    }

    /** Saves the profile row. Sends updated_at the same way the website does (UTC, ISO format). */
    fun upsertProfile(row: JSONObject): Boolean {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
        fmt.timeZone = java.util.TimeZone.getTimeZone("UTC")
        row.put("updated_at", fmt.format(java.util.Date()))
        return authed("POST", "/rest/v1/profiles?on_conflict=id", row.toString(), "resolution=merge-duplicates,return=minimal").ok
    }

    /** The user's training history, newest first, or null if the request failed. */
    fun fetchSessions(): List<JSONObject>? {
        // No cap: ask page by page until the server has nothing more, so All time really is everything.
        // (A server can answer with fewer rows than asked for, so only an empty page ends the loop.)
        val all = ArrayList<JSONObject>()
        var offset = 0
        var pages = 0
        while (pages < 1000) {
            val r = authed("GET", "/rest/v1/sessions?select=*&user_id=eq.${Session.userId}&order=ts.desc&limit=1000&offset=$offset", null, null)
            if (!r.ok) return null
            val page = try {
                JSONArray(r.body).objects()
            } catch (e: Exception) {
                return null
            }
            if (page.isEmpty()) break
            all.addAll(page)
            offset += page.size
            pages++
        }
        return all
    }

    /**
     * Saves one finished training. True means the row can leave the queue:
     *  - saved (2xx);
     *  - 409: the server already has this exact row (an earlier try got through but its answer was lost);
     *  - 400, 403 or 422: the database permanently refused this row (a rule in supabase/migrations). Trying
     *    again can never work, and keeping it would block that row in the queue forever.
     * False (network error, 401, 5xx, 429) means try again later.
     */
    fun insertSession(row: JSONObject): Boolean {
        val r = authed("POST", "/rest/v1/sessions", row.toString(), "return=minimal")
        return r.ok || r.code == 409 || r.code == 400 || r.code == 403 || r.code == 422
    }
}
